Taylor Klone, Section C
No outside help used other than office hours with Baldwin & help in class from Kelly!

"Come to me all who are weary and burdened, and I will give you rest.  Take my yoke upon you and learn from me for I am gentle and humble in heart, and you will find rest for your souls.  For my yoke is easy and my burden is light."
--Matthew 11:28-30

Hi here's a Bible verse that I've been counting on a lot lately and I just really like sharing it!  Have a great weekend!!