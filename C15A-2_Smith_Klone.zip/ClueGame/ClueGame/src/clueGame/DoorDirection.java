package clueGame;

public enum DoorDirection {
	LEFT, RIGHT, UP, DOWN, NONE
}
