package clueGame;

public class BadConfigFormatException extends Exception{

	public BadConfigFormatException() {
		// TODO Auto-generated constructor stub
	}

}
