Quincy Smith & Taylor Klone
I (Taylor) am turning this in and can't add JUnit5 to my library for some reason and I also couldn't access the git log.  Hopefully the first thing won't change anything with our submittal...but I know the second one will.

If it matters, both Quincy and I did equal amounts of work on it though!