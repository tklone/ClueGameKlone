
package experiment;

import java.util.HashSet;
import java.util.Set;

public class TestBoard {
	
	final static int ROW = 4;
	final static int COL = 4;
	
	private Set<TestBoardCell> targets = new HashSet<TestBoardCell>();

	public static TestBoardCell[][] matrix = new TestBoardCell[ROW][COL];
	
	//A constructor that sets up the board.
	public TestBoard() {
		for(int i = 0; i < ROW; i++) {
			for(int j = 0; j < COL; j++) {
				matrix[i][j] = new TestBoardCell(i, j);
			}
		}
	}
	
	//calculates legal targets for a move from startCell of length pathlength.
	public void calcTargets(TestBoardCell startCell, int pathlength) {
		
	}
	
	//gets the targets last created by calcTargets()
	public Set<TestBoardCell> getTargets(){
		return targets;
		
	}
	
	//TestBoardCell getCell( int row, int col ) – returns the cell from the board at row, col.
	public TestBoardCell getCell(int row, int col) {
		return matrix[row][col];
	}
	

}
